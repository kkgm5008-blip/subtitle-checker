﻿자막 맞춤법 · AI 컨펌 (프리미어 프로 플러그인) 1.1.0

1. subtitle-checker-premiere-1.1.0.ccx 를 더블클릭해서 설치하세요 (프리미어는 꺼 둔 상태로).
2. 내 Claude 구독으로 쓰려면 (추가 비용 없음):
   - PowerShell에서 다음 명령으로 Claude Code를 설치하고, claude 를 한 번 실행해 로그인하세요.
       irm https://claude.ai/install.ps1 | iex
   - claude-bridge.ps1 을 마우스 오른쪽 버튼으로 눌러 'PowerShell에서 실행'을 고르세요.
     프리미어 패널을 쓰는 동안 그 창을 켜 두면 됩니다.
3. 프리미어에서 창 > UXP 플러그인 > 자막 맞춤법 · AI 컨펌 을 열고,
   설정 탭에서 '구독 연결 확인'을 누르세요.

자세한 설명: GitHub 저장소 subtitle-checker 의 premiere-plugin/README.md
